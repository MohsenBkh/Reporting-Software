# -*- coding: utf-8 -*-
"""Pipeline تولید گزارش — از پروژه تا DOCX و پیش‌نمایش (بخش ۲۲ و ۲۸ سند)."""
from __future__ import annotations

import html as html_mod
from pathlib import Path
from typing import Optional

from app.core.models import Project
from app.core.report_types import (REPORT_TYPE_COMBINED_PROTECTION,
                                   REPORT_TYPE_HEAVY, REPORT_TYPE_RECLOSER,
                                   REPORT_TYPE_SECTIONALIZER, booklet_title,
                                   is_implemented, pending_message)
from app.core.settings import AppSettings
from app.core.validation import validate_project
from app.report.sections import FigureBlock, GeneratedReport, Paragraph, TableSpec
from app.report.template_manager import TemplateManager
from app.report.text_generator import TextGenerator
from app.report.word_generator import WordGenerator
from app.rules.rule_engine import RuleEngine


def make_generator(project: Project, settings: AppSettings,
                   texts: TemplateManager, engine: RuleEngine,
                   charts_dir: Path, image_resolver=None,
                   profile_loader=None):
    """ساخت مولد گزارش متناسب با «نوع گزارش» پروژه (v2.0.0).

    * متقاضیان سنگین → ``TextGenerator``
    * ریکلوزر / سکشنالایزر / ترکیبی → ``ProtectionReportGenerator`` (Report Composer مبتنی بر
      Component + موتور قواعد و موتور متن؛ مستقل از متقاضی سنگین). مولد قدیمی
      ``SectionalizerGenerator`` (v1.3.0) دیگر در مسیر گزارش استفاده نمی‌شود.
    """
    report_type = getattr(project, "report_type", "") or REPORT_TYPE_HEAVY
    if not is_implemented(report_type):
        raise NotImplementedError(pending_message(report_type))
    if report_type in (REPORT_TYPE_RECLOSER, REPORT_TYPE_SECTIONALIZER,
                       REPORT_TYPE_COMBINED_PROTECTION):
        from app.core.studies import StudyKind
        from app.report.composer import ProtectionReportGenerator
        kinds = {REPORT_TYPE_RECLOSER: [StudyKind.RECLOSER],
                 REPORT_TYPE_SECTIONALIZER: [StudyKind.SECTIONALIZER]}.get(
            report_type, [StudyKind.RECLOSER, StudyKind.SECTIONALIZER])
        return ProtectionReportGenerator(project, settings, texts, engine, charts_dir,
                                         image_resolver, profile_loader, kinds=kinds)
    return TextGenerator(project, settings, texts, engine, charts_dir,
                         image_resolver, profile_loader)


def build_sections(project: Project, settings: AppSettings,
                   texts: TemplateManager, engine: RuleEngine,
                   charts_dir: Path, image_resolver=None,
                   profile_loader=None) -> GeneratedReport:
    Path(charts_dir).mkdir(parents=True, exist_ok=True)
    gen = make_generator(project, settings, texts, engine, charts_dir,
                         image_resolver, profile_loader)
    report = GeneratedReport(sections=gen.build_all())
    report.findings = gen.findings
    report.warnings = list(gen.report_warnings)
    notice = unresolved_errors_section(project, settings)
    if notice is not None:                    # گزارش با وجود خطا تولید می‌شود، با هشدار آغازین
        report.sections.insert(0, notice)
        report.warnings.append("گزارش با خطاهای رفع‌نشده تولید شد.")
    return report


def unresolved_errors_section(project: Project, settings: AppSettings):
    """بخش «هشدار — نقص‌های رفع‌نشده» (None اگر خطایی نباشد)؛ برای همهٔ انواع گزارش."""
    from app.core.validation import ERROR
    from app.report.sections import ReportSection
    try:
        errs = [i.message for i in validate_project(project, settings) if i.status == ERROR]
    except Exception:  # noqa: BLE001
        return None
    if not errs:
        return None
    return ReportSection("notice_unresolved", "هشدار — نقص‌های رفع‌نشده", [
        Paragraph("این گزارش با وجود نقص‌های زیر تولید شده است و پیش از استفاده باید بازبینی شود:"),
        *[Paragraph(f"• {m}", style="item") for m in errs]])


def generate_docx(project: Project, settings: AppSettings, report: GeneratedReport,
                  out_path: Path) -> Path:
    wg = WordGenerator(project, settings)
    return wg.generate(report, out_path)


def docx_filename(project: Project) -> str:
    import re
    safe = re.sub(r'[\\/:*?"<>|]', "-", project.name or project.title_text())
    return f"{safe}.docx"


def generate_report_full(project: Project, settings: AppSettings,
                         charts_dir: Path, output_dir: Path,
                         texts: Optional[TemplateManager] = None,
                         engine: Optional[RuleEngine] = None,
                         image_resolver=None,
                         profile_loader=None) -> tuple[GeneratedReport, Path, list]:
    """تولید کامل: بخش‌ها + نمودارها + فایل Word. خروجی: (گزارش، مسیر docx، آیتم‌های اعتبارسنجی)."""
    texts = texts or TemplateManager.from_settings(settings)
    engine = engine or RuleEngine()
    items = validate_project(project, settings)
    charts_dir.mkdir(parents=True, exist_ok=True)
    report = build_sections(project, settings, texts, engine, charts_dir,
                            image_resolver, profile_loader)
    output_dir.mkdir(parents=True, exist_ok=True)
    out = output_dir / docx_filename(project)
    generate_docx(project, settings, report, out)
    report.docx_path = str(out)
    return report, out, items


# ---------------------------------------------------------------------------
# پیش‌نمایش HTML (برای Preview داخل برنامه)
# ---------------------------------------------------------------------------
def report_to_html(report: GeneratedReport, project: Project,
                   settings: AppSettings) -> str:
    parts: list[str] = []
    esc = html_mod.escape
    parts.append(f"""
    <div style="text-align:center; margin-bottom:18px;">
      <div style="font-size:15pt; font-weight:bold;">{esc(settings.company_name)}</div>
      <div style="font-size:11pt;">{esc(booklet_title(getattr(project, "report_type", "")))}</div>
      <div style="font-size:13pt; font-weight:bold; margin-top:14px; color:#1F4E79;">{esc(project.title_text())}</div>
      <div style="font-size:10pt; margin-top:8px; color:#555;">
        شماره گزارش: {esc(project.report_number)} &nbsp;|&nbsp; تاریخ: {esc(project.date_jalali)}
      </div>
    </div><hr/>""")

    for i, sec in enumerate(report.sections):
        manual = getattr(sec, "manual", False)
        tag = " ✎" if manual else ""
        parts.append(f'<h2 style="color:#1F4E79;">{i + 1}- {esc(sec.title)}{tag}</h2>')
        for block in sec.blocks:
            if isinstance(block, Paragraph):
                cls = "item" if block.style == "item" else ("note" if block.style == "note" else "body")
                for line in str(block.text).split("\n"):
                    if line.strip():
                        parts.append(f'<p class="{cls}">{esc(line)}</p>')
            elif isinstance(block, TableSpec):
                parts.append(_table_html(block))
            elif isinstance(block, FigureBlock):
                src = Path(block.path).resolve().as_uri()
                parts.append(
                    f'<p style="text-align:center;"><img src="{src}" width="620"/></p>'
                    f'<p style="text-align:center; font-weight:bold;">{esc(block.caption)}</p>')
        parts.append("<hr/>")

    body = "\n".join(parts)
    return f"""<!DOCTYPE html><html dir="rtl" lang="fa"><head><meta charset="utf-8">
<style>
 body {{ font-family: 'B Nazanin','Tahoma','Segoe UI'; font-size: 12pt; direction: rtl;
        margin: 16px; line-height: 1.9; background:#FFFFFF; color:#111111; }}
 p.body {{ text-align: justify; margin: 6px 0; }}
 p.item {{ font-weight: bold; }}
 p.note {{ color: #B00; }}
 h2 {{ font-size: 14pt; border-bottom: 1px solid #ccc; padding-bottom: 4px; }}
 table {{ border-collapse: collapse; margin: 10px auto; direction: rtl; }}
 td, th {{ border: 1px solid #7F7F7F; padding: 5px 10px; font-size: 10.5pt; text-align: center; }}
 th {{ background: #D9E2F3; font-weight: bold; }}
 .cap {{ text-align:center; font-weight:bold; margin: 4px 0 10px; }}
</style></head><body>{body}</body></html>"""


def _table_html(spec: TableSpec) -> str:
    esc = html_mod.escape
    cap = f'<p class="cap">{esc(spec.caption)}</p>' if spec.caption else ""
    out = [f'{cap}<table>']
    for row in spec.header_rows:
        out.append("<tr>" + "".join(
            f"<th>{esc(c)}</th>" if c else "<th></th>" for c in row) + "</tr>")
    for row in spec.body_rows:
        out.append("<tr>" + "".join(
            f"<td><b>{esc(c).replace(chr(10), '<br/>')}</b></td>" if i == 0
            else f"<td>{esc(c).replace(chr(10), '<br/>')}</td>"
            for i, c in enumerate(row)) + "</tr>")
    out.append("</table>")
    return "".join(out)
